//
//  LoginViewController.swift
//  Pinterest-2.0
//
//  Created by Renato Berrocal on 6/29/19.
//  Copyright © 2019 Renato Berrocal. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var txtNick: UITextField!
    @IBOutlet weak var txtPass: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func btnLogin(_ sender: UIButton) {
        sender.isEnabled = false
        
        if ((txtNick.text  ?? "").isEmpty){
            showAltert(withTitle: "ERROR", withMessage: "You have empty fields", withAcceptButton: "Back", withCompletion: nil)
        }else{
            if ((txtPass.text  ?? "").isEmpty){
                showAltert(withTitle: "ERROR", withMessage: "You have empty fields", withAcceptButton: "Back", withCompletion: nil)
            }
        }
        
        UserBL.loginUser(nick: self.txtNick.text ?? "", password: self.txtPass.text ?? "", { (message) in
            
            self.performSegue(withIdentifier: "ShowTabBarController", sender: nil)
        }) { (message) in
            self.showAltert(withTitle: "ERROR", withMessage: message, withAcceptButton: "ok", withCompletion: {sender.isEnabled = true})
        }
    }
}
